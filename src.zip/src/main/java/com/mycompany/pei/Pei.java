/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pei;

/**
 *
 * @author uept42-user
 */
public class Pei {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
